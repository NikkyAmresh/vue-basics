<template>
  <div>
    <MessageDisplay />
  </div>
</template>

<script>
import MessageDisplay from '@/components/MessageDisplay'

export default {
  components: {
    MessageDisplay
  }
}
</script>
